package com.tarkeiz.focus

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class BlockedActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val end = intent.getLongExtra("endAt", 0L)
        val mins = ((end - System.currentTimeMillis()).coerceAtLeast(0L) / 60_000L)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(16, 42, 67)); layoutDirection = LinearLayout.LayoutDirection.RTL
        }
        root.addView(TextView(this).apply { text = "وقت التركيز"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        root.addView(TextView(this).apply { text = "هذا التطبيق غير متاح أثناء جلسة التركيز.\n\nارجع إلى هدفك، فكل دقيقة تصنع فرقًا.\n\nالوقت المتبقي تقريبًا: $mins دقيقة"; textSize = 19f; setTextColor(Color.rgb(225,235,245)); gravity = Gravity.CENTER; setPadding(0, 24, 0, 24) })
        val back = TextView(this).apply { text = "العودة"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(24, 16, 24, 16); setBackgroundColor(Color.rgb(37,99,235)); setOnClickListener { finish() } }
        root.addView(back)
        setContentView(root)
    }
    override fun onResume() {
        super.onResume()
        val end = getSharedPreferences("tarkeiz", MODE_PRIVATE).getLong("endAt", 0L)
        if (end <= System.currentTimeMillis()) finish()
    }
}
