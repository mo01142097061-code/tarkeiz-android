package com.tarkeiz.focus

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tarkeiz", Context.MODE_PRIVATE) }
    private val selected = linkedSetOf<String>()
    private var durationMinutes = 60
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected.addAll(prefs.getStringSet("allowed", emptySet()) ?: emptySet())
        selected.add(packageName)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 24)
            setBackgroundColor(Color.rgb(245, 248, 252)); layoutDirection = LinearLayout.LayoutDirection.RTL
        }
        val title = TextView(this).apply { text = "تركيز"; textSize = 32f; setTextColor(Color.rgb(16,42,67)); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        val subtitle = TextView(this).apply { text = "وقتك أغلى من أن يضيع بلا هدف"; textSize = 16f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(0, 8, 0, 24) }
        status = TextView(this).apply { textSize = 14f; setTextColor(Color.rgb(90,100,115)); gravity = Gravity.CENTER; setPadding(0, 0, 0, 16) }
        val durationLabel = TextView(this).apply { text = "اختر مدة التركيز"; textSize = 18f; setTextColor(Color.BLACK) }
        val duration = Spinner(this)
        val labels = listOf("30 دقيقة", "ساعة واحدة", "ساعتان", "3 ساعات", "5 ساعات", "8 ساعات")
        val values = listOf(30, 60, 120, 180, 300, 480)
        duration.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        duration.setSelection(1)
        duration.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { durationMinutes = values[position] }
        }
        val choose = button("اختيار التطبيقات التعليمية المسموح بها") { showAppPicker() }
        val permission = button("تفعيل صلاحية الحظر") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        val start = button("ابدأ جلسة التركيز") { startFocus() }
        val stop = button("إنهاء الجلسة") { prefs.edit().putLong("endAt", 0L).apply(); refreshStatus(); Toast.makeText(this, "انتهت جلسة التركيز", Toast.LENGTH_SHORT).show() }
        val note = TextView(this).apply {
            text = "مهم: يجب تفعيل خدمة «تركيز - حظر التطبيقات» من إعدادات إمكانية الوصول. اختر التطبيقات التعليمية التي تريد إبقاءها متاحة. قد تختلف قوة الحظر حسب إصدار أندرويد والشركة المصنّعة."
            textSize = 13f; setTextColor(Color.rgb(90,100,115)); setPadding(4, 20, 4, 0)
        }
        listOf(title, subtitle, status, durationLabel, duration, choose, permission, start, stop, note).forEach { v ->
            root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (v is Button) 56 else ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = if (v is Button) 10 else 4 })
        }
        setContentView(ScrollView(this).apply { addView(root) })
        refreshStatus()
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 15f; isAllCaps = false; setOnClickListener { action() }
    }

    private fun showAppPicker() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(0).filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val names = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        val checks = BooleanArray(apps.size) { selected.contains(apps[it].packageName) }
        AlertDialog.Builder(this).setTitle("التطبيقات المسموح بها")
            .setMultiChoiceItems(names, checks) { _, which, checked -> if (checked) selected.add(apps[which].packageName) else selected.remove(apps[which].packageName) }
            .setPositiveButton("حفظ") { _, _ ->
                selected.add(packageName)
                prefs.edit().putStringSet("allowed", selected.toSet()).apply()
                Toast.makeText(this, "تم حفظ التطبيقات المسموح بها", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun startFocus() {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any { it.resolveInfo.serviceInfo.packageName == packageName }
        if (!enabled) {
            AlertDialog.Builder(this).setTitle("يلزم تفعيل الصلاحية")
                .setMessage("افتح إعدادات إمكانية الوصول، ثم فعّل خدمة «تركيز - حظر التطبيقات» حتى يستطيع التطبيق منع فتح التطبيقات غير المسموح بها.")
                .setPositiveButton("فتح الإعدادات") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("لاحقًا", null).show()
            return
        }
        prefs.edit().putLong("endAt", System.currentTimeMillis() + durationMinutes * 60_000L).putStringSet("allowed", selected.toSet()).apply()
        refreshStatus()
        Toast.makeText(this, "بدأت جلسة التركيز", Toast.LENGTH_SHORT).show()
    }

    private fun refreshStatus() {
        val end = prefs.getLong("endAt", 0L)
        val remaining = end - System.currentTimeMillis()
        status.text = if (remaining > 0) "جلسة نشطة • المتبقي ${remaining / 3_600_000} س و ${(remaining / 60_000) % 60} د" else "لا توجد جلسة نشطة"
    }
}
