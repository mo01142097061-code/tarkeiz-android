package com.tarkeiz.focus

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppBlockService : AccessibilityService() {
    private var lastBlockedPackage: String? = null
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED)) return
        val pkg = event.packageName?.toString() ?: return
        val prefs = getSharedPreferences("tarkeiz", MODE_PRIVATE)
        val endAt = prefs.getLong("endAt", 0L)
        if (endAt <= System.currentTimeMillis()) {
            if (endAt != 0L) prefs.edit().putLong("endAt", 0L).apply()
            lastBlockedPackage = null
            return
        }
        val allowed = prefs.getStringSet("allowed", emptySet()) ?: emptySet()
        if (pkg == packageName || allowed.contains(pkg)) {
            lastBlockedPackage = null
            return
        }
        if (lastBlockedPackage != pkg) {
            lastBlockedPackage = pkg
            val intent = Intent(this, BlockedActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_HISTORY)
                putExtra("endAt", endAt)
            }
            startActivity(intent)
        }
    }
    override fun onInterrupt() {}
}
